from colorama import Fore


def main():
    print(Fore.YELLOW + "Hello!")


if __name__ == '__main__':
    main()

